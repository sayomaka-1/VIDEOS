import { Component } from '@angular/core';
import { Firebase } from '@ionic-native/firebase/ngx'

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  constructor(private firebase : Firebase){}

  ionViewDidEnter() {
    console.log("Tab 3");
    this.firebase.setScreenName("Tab 3")
  }
}






