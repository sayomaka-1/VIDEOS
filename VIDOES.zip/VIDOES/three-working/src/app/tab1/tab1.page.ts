import { Component } from '@angular/core';
import { Firebase } from '@ionic-native/firebase/ngx';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  constructor(private firebase : Firebase){}

  ionViewDidEnter(){
    console.log("tab 1")
    this.firebase.setScreenName("tab q")
  }
}
